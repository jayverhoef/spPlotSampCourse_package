#-------------------------------------------------------------------------------
#
#           plotPointsRGB
#
#-------------------------------------------------------------------------------


#' @rdname plotPointsRGB
#' @export plotPointsRGB
plotPointsRGB <- function(x, ...){
  UseMethod("plotPointsRGB")
}

