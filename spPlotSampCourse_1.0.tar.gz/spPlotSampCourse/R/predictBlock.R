#-------------------------------------------------------------------------------
#
#           predictBlock
#
#-------------------------------------------------------------------------------


#' @rdname predictBlock
#' @export predictBlock
predictBlock <- function(x, ...){
  UseMethod("predictBlock")
}

