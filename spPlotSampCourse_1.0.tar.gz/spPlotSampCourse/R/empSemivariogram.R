#-------------------------------------------------------------------------------
#
#           empSemivariogram
#
#-------------------------------------------------------------------------------


#' @rdname empSemivariogram
#' @export empSemivariogram
empSemivariogram <- function(x, ...){
  UseMethod("empSemivariogram")
}

