#-------------------------------------------------------------------------------
#
#           predictBlockFinPop
#
#-------------------------------------------------------------------------------


#' @rdname predictBlockFinPop
#' @export predictBlockFinPop
predictBlockFinPop <- function(x, ...){
  UseMethod("predictBlockFinPop")
}

