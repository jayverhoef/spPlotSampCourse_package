#-------------------------------------------------------------------------------
#
#           plotPointsRGBT
#
#-------------------------------------------------------------------------------


#' @rdname plotPointsRGBT
#' @export plotPointsRGBT
plotPointsRGBT <- function(x, ...){
  UseMethod("plotPointsRGBT")
}

