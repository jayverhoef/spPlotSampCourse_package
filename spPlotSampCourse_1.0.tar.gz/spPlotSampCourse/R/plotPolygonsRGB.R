#-------------------------------------------------------------------------------
#
#           plotPolygonsRGB
#
#-------------------------------------------------------------------------------


#' @rdname plotPolygonsRGB
#' @export plotPolygonsRGB
plotPolygonsRGB <- function(x, ...){
  UseMethod("plotPolygonsRGB")
}

