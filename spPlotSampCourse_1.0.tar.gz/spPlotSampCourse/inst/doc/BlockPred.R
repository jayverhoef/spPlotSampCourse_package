### R code from vignette source 'BlockPred.Rnw'

