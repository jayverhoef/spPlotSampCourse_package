### R code from vignette source 'CountSamp.Rnw'

