### R code from vignette source 'BlockPredFinGrid.Rnw'

