### R code from vignette source 'IntroToSpatialStat.Rnw'

