### R code from vignette source 'Introduction.Rnw'

